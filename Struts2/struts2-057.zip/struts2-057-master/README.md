# struts2-057
## checking a url if have struts2-057 vul
## 在domain.txt中每行填入一个域名或者ip:端口 前面带不带协议无所谓
## 然后在cmd中运行struts2-057.exe
## 如果有漏洞 会做如下显示：
## PS E:\py project\PythonWeekly\struts2-057> .\struts2-057.exe
## vul detected: http://192.168.3.85:9001/S2-045