# S2-056-DoS


## 漏洞描述

S2-056漏洞发生于Apache Struts2的REST插件，当使用XStream组件对XML格式的数据包进行反序列化操作，且未对数据内容进行有效验证时，攻击者可通过提交恶意XML数据对应用进行远程DoS攻击。

## 漏洞编号

CVE-2018-1327

## 影响版本

Struts 2.1.1 - Struts 2.5.14.1

## 演示

复现需注意，S2-056消耗的是服务器内存资源，添加JAVA_OPTS=-Xms256m -Xmx512m修改Tomcat内存大小进行DoS。

\bin\catalina.bat

\bin\catalina.sh

```
rem ----- Execute The Requested Command ---------------------------------------
set JAVA_OPTS=-Xms256m -Xmx512m
echo Using CATALINA_BASE:   "%CATALINA_BASE%"
echo Using CATALINA_HOME:   "%CATALINA_HOME%"
echo Using CATALINA_TMPDIR: "%CATALINA_TMPDIR%"
if ""%1"" == ""debug"" goto use_jdk
echo Using JRE_HOME:        "%JRE_HOME%"
goto java_dir_displayed
:use_jdk
echo Using JAVA_HOME:       "%JAVA_HOME%"
:java_dir_displayed
echo Using CLASSPATH:       "%CLASSPATH%"
```


如Tomcat默认配置需使用更多肉鸡来进行攻击。

![exploit](https://github.com/iBearcat/S2-056-DDOS/blob/master/exploit.png?raw=true)

1、攻击成本可以说是比较高，拼资源。
2、REST插件用的较少，因此漏洞威胁较小。

## 修复建议

Apache Struts官方在新版本2.5.16版本中针对S2-056漏洞进行了防护，建议应用Apache Struts2 REST插件的用户排查框架版本是否受漏洞影响，及时升级框架并替换XML解析器为Jackson XML处理类JacksonXmlHandler。

升级应用框架 Apache Struts 2.5.16 ：http://struts.apache.org/download.cgi


## 相关链接

https://cwiki.apache.org/confluence/display/WW/S2-056
